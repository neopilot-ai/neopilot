import os
import boto3 as base_boto3


class boto3class:
    def __init__(self):
        model_path = f'{os.path.abspath(os.path.dirname(__file__))}/models'
        if model_path not in base_boto3._get_default_session()._loader.search_paths:
            base_boto3._get_default_session()._loader.search_paths.extend([model_path])

    def __getattr__(self, attr):
        return getattr(base_boto3, attr)


boto3 = boto3class()
